'use strict';
/* شاه حکم — سرور آزمایشی (Node.js، بدون نیاز به نصب کتابخانه)
   اجرا: node server.js   (پورت پیش‌فرض ۳۰۰۰، با PORT=4000 node server.js عوض می‌شود) */
const http=require('http'),crypto=require('crypto'),os=require('os');
const PORT=+process.env.PORT||3000,SP=+process.env.SPEED||1,GRACE=6000/SP;
const SUITS=['S','H','D','C'],RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'],VAL={};RANKS.forEach((r,i)=>VAL[r]=i+2);
const rnd=n=>crypto.randomInt(n);
const players=new Map(),rooms=new Map(),chatLog=[];
const PTS={'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':20,'Q':3,'K':4,'A':11};
/* ---------- WebSocket ---------- */
function frame(str){const b=Buffer.from(str),n=b.length;let h;if(n<126)h=Buffer.from([0x81,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}return Buffer.concat([h,b])}
class Conn{
 constructor(sock){this.sock=sock;this.buf=Buffer.alloc(0);this.alive=Date.now();this.pid=null;this.parts=[];this.dead=false;
  sock.on('data',d=>this.data(d));sock.on('close',()=>this.closed());sock.on('error',()=>{})}
 send(o){if(this.dead||this.sock.destroyed)return;try{this.sock.write(frame(JSON.stringify(o)))}catch(e){}}
 data(d){this.alive=Date.now();this.buf=Buffer.concat([this.buf,d]);
  for(;;){const b=this.buf;if(b.length<2)return;const op=b[0]&15,fin=b[0]&128;let len=b[1]&127,off=2;
   if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
   const masked=b[1]&128;if(masked)off+=4;if(len>4e6){this.sock.destroy();return}if(b.length<off+len)return;
   const p=Buffer.from(b.subarray(off,off+len));if(masked){const m=b.subarray(off-4,off);for(let i=0;i<p.length;i++)p[i]^=m[i&3]}
   this.buf=b.subarray(off+len);
   if(op===8){this.sock.end();return}if(op===9){this.sock.write(Buffer.concat([Buffer.from([0x8a,p.length]),p]));continue}if(op===10)continue;
   this.parts.push(p);
   if(fin){const s=Buffer.concat(this.parts).toString();this.parts=[];let m;try{m=JSON.parse(s)}catch(e){continue}try{onMsg(this,m)}catch(e){console.error('خطا در پیام',e)}}}}
 closed(){if(this.dead)return;this.dead=true;onClose(this)}}
const server=http.createServer((q,r)=>{r.writeHead(200,{'content-type':'text/plain;charset=utf-8','access-control-allow-origin':'*'});console.log('[HTTP] '+q.socket.remoteAddress);r.end('Shah Hokm server OK')});
server.on('upgrade',(req,sock)=>{const key=req.headers['sec-websocket-key'];if(!key){sock.destroy();return}
 const acc=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');sock.setNoDelay(true);console.log('[WS] اتصال جدید از '+sock.remoteAddress);new Conn(sock)});
const conns=new Set();const _c=Conn.prototype.constructor;
setInterval(()=>{const t=Date.now();for(const p of players.values()){const c=p.conn;if(!c)continue;if(t-c.alive>50000){c.sock.destroy();continue}try{c.sock.write(Buffer.from([0x89,0]))}catch(e){}}},20000);
/* ---------- helpers ---------- */
const CODE='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode(){for(;;){let s='';for(let i=0;i<5;i++)s+=CODE[rnd(CODE.length)];if(!rooms.has(s))return s}}
const sortH=h=>h.sort((a,b)=>SUITS.indexOf(a.s)-SUITS.indexOf(b.s)||VAL[a.r]-VAL[b.r]);
function fresh(){const d=[];for(const s of SUITS)for(const r of RANKS)d.push({s,r});for(let k=0;k<2;k++)for(let i=d.length-1;i>0;i--){const j=rnd(i+1);[d[i],d[j]]=[d[j],d[i]]}return d}
const seatOf=(room,pid)=>room.seats.findIndex(s=>s&&s.pid===pid);
const connOf=s=>{if(!s||!s.pid)return null;const p=players.get(s.pid);return p&&p.conn&&!p.conn.dead?p.conn:null};
function view(room,pid){return{t:'room',code:room.code,host:room.host,rounds:room.rounds,lim:room.lim,size:room.seats.length,voice:[...(room.voice||[])],state:room.state,game:room.game,theme:room.theme,me:seatOf(room,pid),
 seats:room.seats.map(s=>s?{name:s.name,av:s.av,bot:!!s.bot,conn:s.bot?true:s.conn!==false,hold:!!s.hold,pid:s.pid||null}:null)}}
function sendRoom(room){room.seats.forEach(s=>{const c=connOf(s);if(c)c.send(view(room,s.pid))})}
function toAll(room,fn){room.seats.forEach((s,i)=>{const c=connOf(s);if(c){const o=fn(i);if(o)c.send(o)}})}
function destroyRoom(room){if(room.g)clearT(room.g);room.voice=new Set();rooms.delete(room.code);for(const s of room.seats)if(s&&s.pid){const p=players.get(s.pid);if(p&&p.room===room.code)p.room=null}}
function clearT(g){(g.timers||[]).forEach(clearTimeout);g.timers=[]}
function later(room,ms,f){const g=room.g;if(!g)return;const id=setTimeout(()=>{if(room.g===g&&rooms.get(room.code)===room)try{f()}catch(e){console.error(e)}},ms/SP);g.timers.push(id)}
function humansLeft(room){return room.seats.some(s=>s&&!s.bot&&s.pid)}
/* ---------- Hokm engine ---------- */
function beats(g,a,b){if(a.s===b.s)return VAL[a.r]>VAL[b.r];if(a.s===g.trump&&b.s!==g.trump)return true;if(b.s===g.trump&&a.s!==g.trump)return false;return a.s===g.lead&&b.s!==g.lead}
function winning(g){let w=g.trick[0];for(const x of g.trick.slice(1))if(beats(g,x.c,w.c))w=x;return w}
function legalCards(g,p){const h=g.hands[p];if(g.lead){const f=h.filter(c=>c.s===g.lead);if(f.length)return f}return h}
function aiTrump(h){let b,bs=-1;for(const s of SUITS){const k=h.filter(c=>c.s===s),v=k.length*20+k.reduce((a,c)=>a+VAL[c.r],0);if(v>bs){bs=v;b=s}}return b}
function botCard(g,me){const legal=legalCards(g,me),low=a=>a.slice().sort((x,y)=>VAL[x.r]-VAL[y.r]);
 const dump=a=>{const n=a.filter(x=>x.s!==g.trump);return low(n.length?n:a)[0]};
 if(!g.trick.length){const bs=legal.filter(x=>VAL[x.r]>=13),nt=bs.filter(x=>x.s!==g.trump);return nt.length?low(nt).pop():bs.length?low(bs).pop():dump(legal)}
 const w=winning(g),ws=legal.filter(x=>beats(g,x,w.c));
 if(w.p%2===me%2&&(g.trick.length===3||VAL[w.c.r]>=12))return dump(legal);
 return ws.length?low(ws)[0]:dump(legal)}
const isAuto=(room,i)=>{const s=room.seats[i];if(!s)return true;if(s.bot)return true;return !!s.hold&&(s.conn!==false||Date.now()-(s.dcAt||0)>=GRACE)};
function startGame(room){if(room.game==='k7'){k7Start(room);return}hokmStart(room)}
function hokmStart(room){room.state='play';room.g={timers:[],scores:[0,0],hakem:null,round:0,target:room.rounds,phase:'idle',hands:[[],[],[],[]],trick:[],lead:null,tricks:[0,0],trump:null,current:0};
 sendRoom(room);newRound(room)}
function newRound(room){const g=room.g;clearT(g);g.deck=fresh();g.hands=[[],[],[],[]];g.trick=[];g.lead=null;g.tricks=[0,0];g.trump=null;g.phase='deal';g.dp=0;
 if(g.hakem===null){const st=rnd(4),seq=[];let i=0,p;for(;;){p=(st+3*i)%4;const c=g.deck[i];seq.push({p,c});i++;if(c.r==='A')break}g.hakem=p;g.phase='hk';
  toAll(room,()=>({t:'hk',seq,hakem:p}));later(room,(2+seq.length)*620+2400,()=>dealFirst(room))}
 else dealFirst(room)}
function dealFirst(room){const g=room.g;g.deck=fresh();g.dp=0;g.hands=[[],[],[],[]];for(let k=0;k<4;k++){const p=(g.hakem+3*k)%4;for(let n=0;n<5;n++)g.hands[p].push(g.deck[g.dp++])}g.hands.forEach(sortH);g.phase='trump';
 toAll(room,i=>({t:'deal5',hand:g.hands[i],hakem:g.hakem,round:g.round,scores:g.scores}));trumpWait(room)}
function trumpWait(room){const g=room.g;if(g.phase!=='trump')return;const h=g.hakem;
 if(isAuto(room,h))later(room,1800,()=>{if(g.phase==='trump'&&isAuto(room,h))doTrump(room,aiTrump(g.hands[h]));else trumpWait(room)});
 else later(room,1500,()=>trumpWait(room))}
function doTrump(room,s){const g=room.g;if(g.phase!=='trump'||!SUITS.includes(s))return;g.trump=s;
 for(let r=0;r<2;r++)for(let k=0;k<4;k++){const p=(g.hakem+3*k)%4;for(let n=0;n<4;n++)g.hands[p].push(g.deck[g.dp++])}g.hands.forEach(sortH);
 g.phase='announce';g.current=g.hakem;toAll(room,i=>({t:'trump',s,hakem:g.hakem,hand:g.hands[i]}));
 later(room,2700,()=>{g.phase='play';turn(room)})}
function turn(room){const g=room.g;toAll(room,()=>({t:'turn',cur:g.current,tricks:g.tricks}));botCheck(room)}
function botCheck(room){const g=room.g;if(!g||g.phase!=='play')return;const p=g.current,cur=g.current;
 if(isAuto(room,p))later(room,700+rnd(700),()=>{if(g.phase==='play'&&g.current===cur&&isAuto(room,cur)){const c=botCard(g,cur);playCard(room,cur,c)}else if(g.phase==='play'&&g.current===cur)botCheck(room)});
 else if(room.seats[p]&&!room.seats[p].bot)later(room,1000,()=>{if(g.phase==='play'&&g.current===cur)botCheck(room)})}
function playCard(room,p,c){const g=room.g,h=g.hands[p],ix=h.findIndex(x=>x.s===c.s&&x.r===c.r);if(ix<0)return false;h.splice(ix,1);if(!g.trick.length)g.lead=c.s;g.trick.push({p,c});g.current=(p+3)%4;
 toAll(room,()=>({t:'played',p,c}));
 if(g.trick.length===4){g.phase='resolve';later(room,1700,()=>resolveTrick(room))}else{g.phase='play';turn(room)}return true}
function resolveTrick(room){const g=room.g,w=winning(g).p;g.tricks[w%2]++;g.trick=[];g.lead=null;g.current=w;
 if(g.tricks[0]>=7||g.tricks[1]>=7){roundEnd(room);return}g.phase='play';turn(room)}
function roundEnd(room){const g=room.g,team=g.tricks[0]>=7?0:1,kot=g.tricks[1-team]===0,pts=kot?(g.hakem%2!==team?3:2):1;g.scores[team]+=pts;g.round++;
 const nextHakem=(team===g.hakem%2)?g.hakem:(g.hakem+3)%4,over=g.scores[team]>=g.target;g.phase=over?'over':'roundEnd';
 toAll(room,()=>({t:'roundEnd',team,pts,kot,tricks:g.tricks,scores:g.scores,over,hakem:nextHakem,target:g.target}));g.hakem=nextHakem;
 if(over){room.state='over';sendRoom(room)}else later(room,5200,()=>newRound(room))}
function legalHuman(g,p,c){const h=g.hands[p];if(!h.some(x=>x.s===c.s&&x.r===c.r))return false;if(g.lead&&c.s!==g.lead&&h.some(x=>x.s===g.lead))return false;return true}
function snap(room,pid){const g=room.g,s=seatOf(room,pid);if(!g)return null;
 return{t:'snap',room:view(room,pid),g:{phase:g.phase,hakem:g.hakem,trump:g.trump,current:g.current,trick:g.trick,lead:g.lead,tricks:g.tricks,scores:g.scores,round:g.round,target:g.target,counts:g.hands.map(h=>h.length),hand:s>=0?g.hands[s]:[]}}}
/* ---------- messages ---------- */
const clip=(s,n)=>typeof s==='string'?s.slice(0,n):'';
function voiceOff(room,pid){if(room.voice&&room.voice.delete(pid))toAllSeats(room,{t:'vstate',list:[...room.voice]})}
function toAllSeats(room,o){room.seats.forEach(s=>{const c=connOf(s);if(c)c.send(o)})}
function removeFromRoom(room,pid,permanent){const i=seatOf(room,pid);if(i<0)return;const p=players.get(pid);if(p)p.room=null;voiceOff(room,pid);
 if(room.state==='lobby'){room.seats[i]=null;if(room.host===pid){const n=room.seats.find(s=>s&&s.pid);room.host=n?n.pid:null}}
 else{room.seats[i]={bot:true,name:'ربات '+(i+1),av:null,pid:null,conn:true};if(room.host===pid){const n=room.seats.find(s=>s&&s.pid);room.host=n?n.pid:null}}
 if(!humansLeft(room)){destroyRoom(room);return}sendRoom(room)}
function onMsg(c,m){
 if(m.t==='hello'){const pid=clip(String(m.pid||''),40);if(pid.length<8){c.send({t:'err',msg:'شناسه نامعتبر'});return}
  let p=players.get(pid);if(!p){p={pid,room:null,conn:null};players.set(pid,p)}
  if(p.conn&&p.conn!==c&&!p.conn.dead){const o=p.conn;p.conn=null;o.dead=true;try{o.sock.destroy()}catch(e){}}
  p.conn=c;c.pid=pid;p.name=clip(m.name,24)||'بازیکن';p.av=clip(m.av,90000)||null;console.log('[ورود] '+p.name);c.send({t:'ready',pid});c.send({t:'chatHist',list:chatLog.slice(-60)});
  const room=p.room&&rooms.get(p.room);if(room){const i=seatOf(room,pid);if(i>=0){const s=room.seats[i];s.name=p.name;if(p.av)s.av=p.av;s.conn=true;
    if(room.state==='lobby'){clearTimeout(s.lt);sendRoom(room)}else{s.dcAt=0;c.send({t:'resume',code:room.code});sendRoom(room)}}else p.room=null}
  return}
 const p=players.get(c.pid);if(!p||p.conn!==c)return;
 const room=p.room&&rooms.get(p.room);
 switch(m.t){
 case 'ping':c.send({t:'pong'});break;
 case 'create':{if(room)removeFromRoom(room,p.pid);
  let th=m.theme&&typeof m.theme==='object'?m.theme:{};const sz=JSON.stringify(th).length;if(sz>900000)th={f:th.f|0,b:th.b|0,g:th.g|0,cs:th.cs|0};
  const code=newCode(),k7=m.game==='k7',size=k7?Math.max(2,Math.min(6,m.size|0||4)):4,seats=Array(size).fill(null);seats[0]={pid:p.pid,name:p.name,av:p.av,bot:false,conn:true};
  const r={code,game:k7?'k7':'hokm',host:p.pid,rounds:[3,5,7].includes(m.rounds)?m.rounds:7,lim:k7?Math.max(100,Math.min(600,Math.round((m.lim|0||200)/100)*100)):0,voice:new Set(),state:'lobby',theme:th,seats,g:null};
  rooms.set(code,r);p.room=code;sendRoom(r);break}
 case 'join':{const code=clip(String(m.code||''),8).toUpperCase().trim(),r=rooms.get(code);
  if(!r){c.send({t:'err',msg:'میزی با این کد پیدا نشد'});break}
  if(room&&room!==r)removeFromRoom(room,p.pid);
  if(seatOf(r,p.pid)>=0){sendRoom(r);break}
  if(r.state!=='lobby'){c.send({t:'err',msg:'بازی این میز شروع شده است'});break}
  const i=r.seats.findIndex(s=>!s);if(i<0){c.send({t:'err',msg:'میز پر است'});break}
  r.seats[i]={pid:p.pid,name:p.name,av:p.av,bot:false,conn:true};p.room=code;sendRoom(r);break}
 case 'cfg':if(room&&room.state==='lobby'&&room.host===p.pid){
  if(room.game==='hokm'&&[3,5,7].includes(m.rounds))room.rounds=m.rounds;
  if(room.game==='k7'){if(m.lim)room.lim=Math.max(100,Math.min(600,Math.round(m.lim/100)*100));
   if(m.size){const n=Math.max(2,Math.min(6,m.size|0));if(room.seats.slice(n).every(x=>!x)){while(room.seats.length<n)room.seats.push(null);room.seats.length=n}}}
  sendRoom(room)}break;
 case 'swap':if(room&&room.state==='lobby'&&room.host===p.pid){const a=m.a|0,b=m.b|0;if(a>=0&&a<room.seats.length&&b>=0&&b<room.seats.length&&a!==b){[room.seats[a],room.seats[b]]=[room.seats[b],room.seats[a]];sendRoom(room)}}break;
 case 'start':if(room&&room.state==='lobby'&&room.host===p.pid){for(let i=0;i<room.seats.length;i++)if(!room.seats[i])room.seats[i]={bot:true,name:'ربات '+(i+1),av:null,pid:null,conn:true};startGame(room)}break;
 case 'again':if(room&&room.state==='over'&&room.host===p.pid){room.seats.forEach((s,i)=>{if(s&&s.pid&&!connOf(s)){room.seats[i]={bot:true,name:'ربات '+(i+1),av:null,pid:null,conn:true}}});startGame(room)}break;
 case 'trump':if(room&&room.g&&room.g.phase==='trump'&&seatOf(room,p.pid)===room.g.hakem)doTrump(room,m.s);break;
 case 'play':{if(!room||!room.g||room.g.phase!=='play')break;const g=room.g,i=seatOf(room,p.pid),s=room.seats[i];
  if(i<0||g.current!==i||s.hold){c.send({t:'rej',why:'turn'});break}
  const cd=m.c||{};if(!legalHuman(g,i,cd)){c.send({t:'rej',why:'illegal'});break}playCard(room,i,{s:cd.s,r:cd.r});break}
 case 'resumeYes':if(room&&room.state!=='lobby'){const i=seatOf(room,p.pid);if(i>=0){room.seats[i].hold=false;room.seats[i].conn=true;const sn=room.game==='k7'?kView(room,p.pid):snap(room,p.pid);if(sn)c.send(sn);sendRoom(room)}}break;
 case 'vjoin':if(room){room.voice.add(p.pid);toAllSeats(room,{t:'vstate',list:[...room.voice]})}break;
 case 'vleave':if(room)voiceOff(room,p.pid);break;
 case 'rtc':{if(!room)break;const t=players.get(String(m.to||''));if(t&&t.conn&&t.room===room.code&&room.voice.has(p.pid))t.conn.send({t:'rtc',from:p.pid,d:m.d});break}
 case 'chat':{const x=clip(String(m.x||''),200).trim();if(!x)break;const now=Date.now();if(now-(p.lastChat||0)<600)break;p.lastChat=now;const msg={n:p.name,p:p.pid,x,ts:now};chatLog.push(msg);if(chatLog.length>150)chatLog.shift();for(const q of players.values())if(q.conn&&!q.conn.dead)q.conn.send({t:'chat',m:msg});break}
 case 'kplay':if(room&&room.game==='k7'&&room.k)kHumanPlay(room,p.pid,m.c);break;
 case 'kdraw':if(room&&room.game==='k7'&&room.k)kHumanDraw(room,p.pid);break;
 case 'kpass':if(room&&room.game==='k7'&&room.k)kHumanPass(room,p.pid);break;
 case 'ksuit':if(room&&room.game==='k7'&&room.k)kHumanSuit(room,p.pid,m.s);break;
 case 'ktarget':if(room&&room.game==='k7'&&room.k)kHumanTarget(room,p.pid,m.to|0);break;
 case 'kuno':if(room&&room.game==='k7'&&room.k)kHumanUno(room,p.pid);break;
 case 'resumeNo':if(room)removeFromRoom(room,p.pid);c.send({t:'left'});break;
 case 'leave':if(room)removeFromRoom(room,p.pid);c.send({t:'left'});break;
 }}
function onClose(c){const p=c.pid&&players.get(c.pid);if(!p||p.conn!==c)return;p.conn=null;
 const room=p.room&&rooms.get(p.room);if(!room)return;const i=seatOf(room,p.pid);if(i<0)return;const s=room.seats[i];s.conn=false;
 if(room.state==='lobby'){s.lt=setTimeout(()=>{const r=rooms.get(room.code);if(r&&seatOf(r,p.pid)>=0&&r.seats[seatOf(r,p.pid)].conn===false)removeFromRoom(r,p.pid)},20000);sendRoom(room)}
 else{s.hold=true;s.dcAt=Date.now();sendRoom(room);voiceOff(room,p.pid);if(room.g&&room.game==='hokm'){if(room.g.phase==='play')botCheck(room);else if(room.g.phase==='trump')trumpWait(room)}
  setTimeout(()=>{const r=rooms.get(room.code);if(r&&r.seats.every(x=>!x||x.bot||x.conn===false)){const dead=r.seats.every(x=>!x||x.bot||Date.now()-(x.dcAt||0)>120000);if(dead)destroyRoom(r)}},125000)}}

/* ---------- هفت خبیث ---------- */
const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
const kAct=k=>k.pl.map((p,i)=>i).filter(i=>!k.pl[i].out);
const kNxt=(k,i,d)=>{d=d||k.dir;let n=0;do{i=(i+d+k.n)%k.n;n++}while(k.pl[i].out&&n<=k.n);return i};
function kLegal(k,c){if(k.pending>0)return c.r==='7';if(k.bonus)return c.s===k.bonus.suit||c.r==='8';const t=k.disc[k.disc.length-1];if(!t)return true;if(c.r==='J')return c.s===k.cur;return c.s===k.cur||c.r===t.r}
function kView(room,pid){const k=room.k,me=seatOf(room,pid);return{t:'kstate',n:k.n,lim:k.lim,rno:k.rno,turn:k.turn,dir:k.dir,cur:k.cur,pending:k.pending,bonus:k.bonus?k.bonus.suit:null,disc:k.disc.slice(-4),discN:k.disc.length,drawN:k.draw.length,phase:k.phase,
 aw:k.aw?{kind:k.aw.kind,who:k.aw.who}:null,me,pl:k.pl.map((p,i)=>({tot:p.tot,out:p.out,n:p.hand.length,hand:i===me?p.hand:null}))}}
function kSend(room){room.seats.forEach(s=>{const c=connOf(s);if(c)c.send(kView(room,s.pid))})}
function kMsg(room,x){toAllSeats(room,{t:'kmsg',x})}
const kName=(room,i)=>room.seats[i]?room.seats[i].name:'بازیکن';
function k7Start(room){const n=room.seats.length;room.state='play';
 const k=room.k={timers:[],n,lim:room.lim,pl:room.seats.map(()=>({tot:0,out:false,hand:[]})),rno:0,starter:0,phase:'idle',aw:null,pending:0,bonus:null,dir:1,turn:0,cur:'S',draw:[],disc:[],stall:0,uno:null,tid:0,lock:true};
 room.g=k;sendRoom(room);k7New(room)}
function k7New(room){const k=room.k;clearT(k);k.rno++;k.phase='deal';k.pending=0;k.bonus=null;k.dir=1;k.aw=null;k.stall=0;k.uno=null;k.lock=true;k.tid++;
 const d=[];for(let q=0;q<(k.n>=5?2:1);q++)for(const s of SUITS)for(const r of RANKS)d.push({s,r});k.draw=shuf(d);k.disc=[];k.pl.forEach(p=>p.hand=[]);
 const order=[];let i=k.starter;do{if(!k.pl[i].out)order.push(i);i=(i+1)%k.n}while(i!==k.starter);
 for(let r=0;r<7;r++)order.forEach(x=>k.pl[x].hand.push(k.draw.pop()));k.pl.forEach(p=>sortH(p.hand));k.turn=k.pl[k.starter].out?kNxt(k,k.starter):k.starter;
 const c=k.draw.pop();k.disc.push(c);k.cur=c.s;toAllSeats(room,{t:'knew',rno:k.rno});kSend(room);later(room,2300,()=>{k.phase='play';kTurn(room)})}
function kTurn(room){const k=room.k;if(k.phase!=='play')return;k.lock=false;kSend(room);const p=k.turn,id=++k.tid;
 if(isAuto(room,p)){later(room,900+rnd(700),()=>{if(k.phase==='play'&&k.turn===p&&k.tid===id)kBot(room,p)});return}
 const L=k.pl[p].hand.filter(c=>kLegal(k,c));
 if(!L.length){k.lock=true;kMsg(room,k.pending>0?kName(room,p)+' جریمه ۷ را برمی‌دارد':kName(room,p)+' کارت قابل بازی ندارد');later(room,1100,()=>{if(k.tid===id&&k.phase==='play'&&k.turn===p){if(k.pending>0)kForced(room,p);else kDrawOne(room,p)}});return}
 toAllSeats(room,{t:'ktm',p});later(room,15000,()=>{if(k.tid===id&&k.phase==='play'&&k.turn===p)toAllSeats(room,{t:'kwarn',p})});
 later(room,30000,()=>{if(k.tid===id&&k.phase==='play'&&k.turn===p)kTimeout(room,p)});kPoll(room,p,id)}
function kPoll(room,p,id){const k=room.k;later(room,1000,()=>{if(k.tid!==id||k.phase!=='play'||k.turn!==p)return;if(isAuto(room,p))kBot(room,p);else kPoll(room,p,id)})}
function kTimeout(room,p){const k=room.k;if(k.aw&&k.aw.who===p){return}k.lock=true;k.tid++;kMsg(room,kName(room,p)+': وقت تمام شد و یک کارت جریمه شد');if(k.pending>0)kForced(room,p);else kDraw(room,p,1,()=>kAdvance(room,p))}
function kDraw(room,p,cnt,cb){const k=room.k,got=[];for(let i=0;i<cnt;i++){if(!k.draw.length){const top=k.disc.pop();k.draw=shuf(k.disc);k.disc=top?[top]:[]}if(!k.draw.length)break;const c=k.draw.pop();k.stall=0;k.pl[p].hand.push(c);got.push(c)}
 sortH(k.pl[p].hand);toAllSeats(room,{t:'kdraw',p,n:got.length});kSend(room);if(cb)later(room,350+got.length*330,()=>cb(got));return got}
function kForced(room,p){const k=room.k,n=k.pending;k.pending=0;k.lock=true;k.tid++;kMsg(room,kName(room,p)+' '+n+' کارت برداشت');kDraw(room,p,n,()=>kAdvance(room,p))}
function kDrawOne(room,p){const k=room.k;k.lock=true;k.tid++;kDraw(room,p,1,got=>{const c=got[0];if(c&&kLegal(k,c)){
  if(isAuto(room,p))later(room,500,()=>kPlay(room,p,c));else{k.aw={kind:'pass',who:p};k.lock=false;kSend(room);const id=++k.tid;later(room,30000,()=>{if(k.tid===id&&k.aw&&k.aw.kind==='pass'&&k.aw.who===p){k.aw=null;kMsg(room,'وقت تمام شد');kAdvance(room,p)}})}}
  else kAdvance(room,p)})}
function kAdvance(room,p){const k=room.k;k.bonus=null;k.aw=null;k.lock=true;
 if(++k.stall>kAct(k).length*3){const pt=i=>k.pl[i].hand.reduce((a,c)=>a+PTS[c.r],0);kEnd(room,kAct(k).sort((a,b)=>pt(a)-pt(b))[0],false);return}
 k.turn=kNxt(k,p);kSend(room);later(room,550,()=>kTurn(room))}
function kPick(k,p,L){const nx=kNxt(k,p),sc=c=>{let v=PTS[c.r];if(c.r==='J')v=-5;if(k.pending>0)return v;if(k.pl[nx].hand.length<=2){if(c.r==='7')v+=30;if(c.r==='A')v+=25;if(c.r==='2')v+=20}if(c.r==='8')v+=3;return v};return L.slice().sort((a,b)=>sc(b)-sc(a))[0]}
function kBot(room,p){const k=room.k;if(k.phase!=='play')return;k.lock=true;const L=k.pl[p].hand.filter(c=>kLegal(k,c));if(L.length){kPlay(room,p,kPick(k,p,L));return}if(k.pending>0){kForced(room,p);return}kDrawOne(room,p)}
function kPlay(room,p,c){const k=room.k,h=k.pl[p].hand,ix=h.findIndex(x=>x.s===c.s&&x.r===c.r);if(ix<0)return;const card=h.splice(ix,1)[0];k.stall=0;k.disc.push(card);k.bonus=null;k.cur=card.s;k.tid++;k.aw=null;k.lock=true;
 toAllSeats(room,{t:'kplay',p,c:card});
 if(!h.length){kSend(room);later(room,800,()=>kEnd(room,p,card.r==='J'));return}
 if(h.length===1)kUno(room,p);
 const R=card.r;
 if(R==='8'){k.bonus={suit:card.s,by:p};k.turn=p;kSend(room);later(room,750,()=>kTurn(room));return}
 if(R==='7')k.pending+=2;
 if(R==='10'){k.dir=-k.dir;if(kAct(k).length===2){k.turn=p;kSend(room);later(room,750,()=>kTurn(room));return}}
 if(R==='A'){const sk=kNxt(k,p);k.turn=kNxt(k,sk);kSend(room);later(room,800,()=>kTurn(room));return}
 if(R==='2'){kTarget(room,p);return}
 if(R==='J'){kSuit(room,p);return}
 kAdvance(room,p)}
function kUno(room,p){const k=room.k,id=k.uno={p};
 if(!isAuto(room,p)){toAllSeats(room,{t:'kuno',p});later(room,3200,()=>{if(k.uno===id&&k.pl[p].hand.length===1){k.uno=null;kMsg(room,kName(room,p)+' تک‌برگ نگفت و یک کارت جریمه شد');kDraw(room,p,1)}})}
 else if(rnd(10)>0)later(room,500,()=>kMsg(room,kName(room,p)+': تک‌برگ!'));else later(room,2000,()=>{if(k.pl[p].hand.length===1){kMsg(room,kName(room,p)+' تک‌برگ نگفت و یک کارت جریمه شد');kDraw(room,p,1)}})}
function kBest(k,p){const cnt={S:0,H:0,D:0,C:0};k.pl[p].hand.forEach(c=>cnt[c.s]++);return SUITS.slice().sort((a,b)=>cnt[b]-cnt[a]||rnd(3)-1)[0]}
function kSuit(room,p){const k=room.k;if(isAuto(room,p)){later(room,500,()=>kSetSuit(room,p,kBest(k,p)));return}
 k.aw={kind:'suit',who:p};k.lock=false;kSend(room);const id=++k.tid;later(room,30000,()=>{if(k.tid===id&&k.aw&&k.aw.kind==='suit'&&k.aw.who===p)kSetSuit(room,p,kBest(k,p))})}
function kSetSuit(room,p,s){const k=room.k;if(!SUITS.includes(s))return;k.aw=null;k.lock=true;k.tid++;k.cur=s;toAllSeats(room,{t:'ksuit',s,p});kSend(room);later(room,1800,()=>kAdvance(room,p))}
function kTarget(room,p){const k=room.k,c=kAct(k).filter(i=>i!==p);
 if(isAuto(room,p)){const t=c.sort((a,b)=>k.pl[a].hand.length-k.pl[b].hand.length||rnd(3)-1)[0];later(room,600,()=>kSetTarget(room,p,t));return}
 k.aw={kind:'target',who:p};k.lock=false;kSend(room);const id=++k.tid;later(room,30000,()=>{if(k.tid===id&&k.aw&&k.aw.kind==='target'&&k.aw.who===p)kSetTarget(room,p,c[rnd(c.length)])})}
function kSetTarget(room,p,t){const k=room.k;if(!(t>=0&&t<k.n)||t===p||k.pl[t].out)return;k.aw=null;k.lock=true;k.tid++;toAllSeats(room,{t:'kchosen',p,to:t});kMsg(room,kName(room,p)+' به '+kName(room,t)+' یک کارت داد');kSend(room);
 later(room,1000,()=>kDraw(room,t,1,()=>later(room,300,()=>kAdvance(room,p))))}
function kEnd(room,w,jack){const k=room.k;k.phase='round';k.tid++;k.lock=true;k.aw=null;const mul=jack?2:1,prev=kAct(k),rows=k.pl.map(()=>({pts:0}));
 prev.forEach(i=>{if(i!==w){const pts=k.pl[i].hand.reduce((a,c)=>a+PTS[c.r],0)*mul;k.pl[i].tot+=pts;rows[i].pts=pts}});
 prev.forEach(i=>{if(k.pl[i].tot>=k.lim)k.pl[i].out=true});const left=kAct(k),humanAlive=left.some(i=>room.seats[i]&&!room.seats[i].bot);
 const fin=left.length<=1||!humanAlive;let win=-1;if(fin){const pool=left.length?left:prev;win=pool.slice().sort((a,b)=>k.pl[a].tot-k.pl[b].tot)[0]}
 k.starter=w;if(k.pl[k.starter].out)k.starter=kNxt(k,k.starter);
 toAllSeats(room,{t:'kround',w,jack,fin,win,rno:k.rno,rows:k.pl.map((p,i)=>({pts:rows[i].pts,tot:p.tot,out:p.out,was:prev.includes(i)}))});kSend(room);
 if(fin){room.state='over';sendRoom(room)}else later(room,8000,()=>k7New(room))}
/* human actions */
function kSeat(room,pid){const i=seatOf(room,pid),k=room.k;return(i>=0&&k&&room.seats[i]&&!room.seats[i].hold)?i:-1}
function kHumanPlay(room,pid,c){const k=room.k,i=kSeat(room,pid);if(i<0||!c)return;const card=k.pl[i].hand.find(x=>x.s===c.s&&x.r===c.r);if(!card)return;
 if(k.phase!=='play'&&k.phase!=='deal')return;
 if(k.turn!==i){if(k.phase==='play'){kMsg(room,kName(room,i)+': نوبتش نبود و یک کارت جریمه شد');kDraw(room,i,1)}return}
 if(k.lock||(k.aw&&k.aw.kind!=='pass'))return;
 if(!kLegal(k,card)){kMsg(room,kName(room,i)+': کارت نامعتبر انداخت و یک کارت جریمه شد');kDraw(room,i,1);return}
 kPlay(room,i,card)}
function kHumanDraw(room,pid){const k=room.k,i=kSeat(room,pid);if(i<0||k.phase!=='play'||k.turn!==i||k.lock||k.aw)return;
 if(k.pending>0){kForced(room,i);return}if(k.pl[i].hand.some(c=>kLegal(k,c))){const cc=connOf(room.seats[i]);if(cc)cc.send({t:'kmsg',x:'کارت قابل بازی داری'});return}kDrawOne(room,i)}
function kHumanPass(room,pid){const k=room.k,i=kSeat(room,pid);if(i<0||!k.aw||k.aw.kind!=='pass'||k.aw.who!==i)return;k.aw=null;k.tid++;kAdvance(room,i)}
function kHumanSuit(room,pid,s){const k=room.k,i=kSeat(room,pid);if(i<0||!k.aw||k.aw.kind!=='suit'||k.aw.who!==i)return;kSetSuit(room,i,s)}
function kHumanTarget(room,pid,t){const k=room.k,i=kSeat(room,pid);if(i<0||!k.aw||k.aw.kind!=='target'||k.aw.who!==i)return;kSetTarget(room,i,t)}
function kHumanUno(room,pid){const k=room.k,i=seatOf(room,pid);if(i<0||!k.uno||k.uno.p!==i)return;k.uno=null;kMsg(room,kName(room,i)+': تک‌برگ!')}

if(require.main===module){server.listen(PORT,'0.0.0.0',()=>{console.log('سرور شاه حکم روی پورت '+PORT+' اجرا شد');
 const nets=os.networkInterfaces();for(const k of Object.keys(nets))for(const n of nets[k])if(n.family==='IPv4'&&!n.internal)console.log('  آدرس برای گوشی:  '+n.address+':'+PORT)})}
module.exports={server,rooms,players};
