package com.tecraft.hokm;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
    private ValueCallback<Uri[]> cb;
    @Override protected void onActivityResult(int rq,int rs,Intent d){
        if(rq==1&&cb!=null){ cb.onReceiveValue(rs==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null); cb=null; } }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        web.addJavascriptInterface(new Object(){ @JavascriptInterface public void exit(){ finish(); } },"Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> c, FileChooserParams p){
                if(cb!=null) cb.onReceiveValue(null); cb=c;
                Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
                startActivityForResult(i,1); return true; }
        });
        web.setBackgroundColor(0xff07150f);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
}
