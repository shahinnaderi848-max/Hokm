package com.tecraft.hokm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {
    private ValueCallback<Uri[]> cb;
    private WebView web;

    @Override protected void onActivityResult(int rq,int rs,Intent d){
        if(rq==1&&cb!=null){ cb.onReceiveValue(rs==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null); cb=null; } }

    private void js(final String s){ runOnUiThread(new Runnable(){ public void run(){ web.evaluateJavascript(s,null); } }); }

    private void cut(Bitmap bmp, SegmentationMask mask){
        ByteBuffer buf = mask.getBuffer();
        int mw = mask.getWidth(), mh = mask.getHeight();
        float[] conf = new float[mw*mh];
        buf.rewind();
        for(int i=0;i<conf.length;i++) conf[i]=buf.getFloat();
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] px = new int[w*h];
        bmp.getPixels(px,0,w,0,0,w,h);
        for(int y=0;y<h;y++){
            int my = Math.min(mh-1, y*mh/h);
            for(int x=0;x<w;x++){
                int mx = Math.min(mw-1, x*mw/w);
                float a = (conf[my*mw+mx]-0.35f)/0.3f;
                if(a<0) a=0; if(a>1) a=1;
                int i = y*w+x;
                px[i] = (((int)(a*255))<<24) | (px[i]&0x00FFFFFF);
            }
        }
        Bitmap out = Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.PNG,100,bo);
        js("onSeg('data:image/png;base64,"+Base64.encodeToString(bo.toByteArray(),Base64.NO_WRAP)+"')");
    }

    class Bridge {
        @JavascriptInterface public void exit(){ finish(); }
        @JavascriptInterface public void segment(String dataUrl){
            try{
                byte[] b = Base64.decode(dataUrl.substring(dataUrl.indexOf(',')+1), Base64.DEFAULT);
                final Bitmap bmp = BitmapFactory.decodeByteArray(b,0,b.length);
                if(bmp==null){ js("onSegFail()"); return; }
                SelfieSegmenterOptions o = new SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build();
                Segmenter sg = Segmentation.getClient(o);
                sg.process(InputImage.fromBitmap(bmp,0))
                  .addOnSuccessListener(mask -> { try{ cut(bmp,mask); }catch(Throwable t){ js("onSegFail()"); } })
                  .addOnFailureListener(e -> js("onSegFail()"));
            }catch(Throwable t){ js("onSegFail()"); }
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        web.addJavascriptInterface(new Bridge(),"Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> c, FileChooserParams p){
                if(cb!=null) cb.onReceiveValue(null); cb=c;
                Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
                startActivityForResult(i,1); return true; }
        });
        web.setBackgroundColor(0xff07150f);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
}
